/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
/**
 * C program to count total number of duplicate elements in an array
 */
#include<stdio.h>
#include<conio.h>
#include<math.h>
int main()
{
    int i,j,n,temp,sum=0,mean,x,y=0;
    int arr[10];
    float variance,st_deviation;
    printf("Enter the size: ");
    scanf("%d",&n);
    printf("Enter the elements: ");
    for(i=0;i<n;i++)
    {
        scanf("%d",&arr[i]);
    }
    for(i=0;i<n;i++)
    {
        for(j=0;j<n-i-1;j++)
        {
            if(arr[j]>arr[j+1])
            {
                temp = arr[j];
                arr[j]=arr[j+1];
                arr[j+1]=temp;
                
            }
        }
    }
    for(i=0;i<n;i++)
    {
        printf("\t %d",arr[i]);
        sum+=arr[i];
        mean=sum/n;
    }
    for(i=0;i<n;i++)
    {
        x=(arr[i]-mean);
        y=y+x*x;
        
    }
    variance =y/n;
    st_deviation = sqrt(variance);
    printf("\n%d",sum);
    printf("\n%d",mean);
    printf("\n%f",variance);
    printf("\n %f",st_deviation);
}